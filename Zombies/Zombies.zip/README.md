# Zombies
<p><em>Rise from your graves!</em></p>
<p>Adds a chance for dead players to come back as Masked.</p>
<p>All players need to have this mod installed.</p>
<p>Currently in alpha, please report any bugs or suggestions to the thread in the LC modding discord.</p>
<h2>Planned Features</h2>
* Different behaviours<br>
* Infection of living players<br>
* Chance of reviving as a non-zombie... or a zombie in disguise
